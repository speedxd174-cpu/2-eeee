import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createAdminAuthService } from './src/server/adminAuth.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

async function startServer() {
  const app = express();
  const authService = createAdminAuthService();

  app.use(express.json({ limit: '16kb' }));

  app.get('/api/admin/auth/status', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json(authService.getStatus());
  });

  app.post('/api/admin/auth/setup', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const code = typeof req.body?.code === 'string' ? req.body.code : '';
    const result = authService.claimInitialCode(code);
    if (!result.ok) {
      res.status(result.status).json({ error: result.error });
      return;
    }
    res.json({ token: result.token, expiresAt: result.expiresAt });
  });

  app.post('/api/admin/auth/login', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const code = typeof req.body?.code === 'string' ? req.body.code : '';
    const result = authService.login(code);
    if (!result.ok) {
      res.status(result.status).json({ error: result.error });
      return;
    }
    res.json({ token: result.token, expiresAt: result.expiresAt });
  });

  app.get('/api/admin/auth/verify', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const payload = authService.verifyBearerHeader(req.headers.authorization);
    if (!payload) {
      res.status(401).json({ authenticated: false });
      return;
    }
    res.json({ authenticated: true, role: payload.role, expiresAt: payload.exp });
  });

  app.post('/api/admin/auth/logout', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    authService.revokeBearerHeader(req.headers.authorization);
    res.json({ ok: true });
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    const indexHtml = path.join(distDir, 'index.html');
    app.use(express.static(distDir, { index: false }));
    app.get('*', (_req, res) => {
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Production build not found. Run npm run build first.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`WF Galaxy server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
