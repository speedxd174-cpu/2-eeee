import crypto from 'node:crypto';

export type AuthMode = 'env' | 'setup' | 'claimed';

export interface SessionPayload {
  role: 'admin';
  jti: string;
  exp: number;
}

export function hashAccessCode(code: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(code, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

export function verifyAccessCodeHash(code: string, storedHash: string): boolean {
  const parts = storedHash.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const [, salt, expectedHex] = parts;
  if (!salt || !expectedHex) return false;
  const expectedBuf = Buffer.from(expectedHex, 'hex');
  const actualBuf = crypto.scryptSync(code, salt, 64);
  if (expectedBuf.length !== actualBuf.length) return false;
  return crypto.timingSafeEqual(expectedBuf, actualBuf);
}

export function timingSafeCompareCode(candidate: string, expected: string): boolean {
  const candidateDigest = crypto.createHash('sha256').update(candidate, 'utf8').digest();
  const expectedDigest = crypto.createHash('sha256').update(expected, 'utf8').digest();
  return crypto.timingSafeEqual(candidateDigest, expectedDigest);
}

export function signSessionToken(secret: string, ttlMs: number = 4 * 60 * 60 * 1000): {
  token: string;
  expiresAt: number;
} {
  const expiresAt = Date.now() + ttlMs;
  const payload: SessionPayload = {
    role: 'admin',
    jti: crypto.randomBytes(12).toString('hex'),
    exp: expiresAt,
  };
  const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payloadB64).digest('base64url');
  return {
    token: `${payloadB64}.${sig}`,
    expiresAt,
  };
}

export function verifySessionToken(
  token: string,
  secret: string,
  now: number = Date.now(),
): SessionPayload | null {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payloadB64, providedSig] = parts;
  if (!payloadB64 || !providedSig) return null;

  const expectedSig = crypto.createHmac('sha256', secret).update(payloadB64).digest('base64url');
  const providedBuf = Buffer.from(providedSig, 'utf8');
  const expectedBuf = Buffer.from(expectedSig, 'utf8');
  if (providedBuf.length !== expectedBuf.length) return null;
  if (!crypto.timingSafeEqual(providedBuf, expectedBuf)) return null;

  try {
    const parsed = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8')) as SessionPayload;
    if (parsed.role !== 'admin' || typeof parsed.exp !== 'number' || typeof parsed.jti !== 'string') {
      return null;
    }
    if (parsed.exp <= now) return null;
    return parsed;
  } catch {
    return null;
  }
}

export interface AdminAuthService {
  getStatus: () => { mode: AuthMode; configured: boolean };
  claimInitialCode: (
    code: string,
  ) => { ok: true; token: string; expiresAt: number } | { ok: false; status: number; error: string };
  login: (
    code: string,
  ) => { ok: true; token: string; expiresAt: number } | { ok: false; status: number; error: string };
  verifyBearerHeader: (authHeader: string | undefined) => SessionPayload | null;
  revokeBearerHeader: (authHeader: string | undefined) => void;
}

export function createAdminAuthService(options?: {
  getEnvCode?: () => string;
  sessionSecret?: string;
}): AdminAuthService {
  const getEnvCode = options?.getEnvCode ?? (() => (process.env.ADMIN_ACCESS_CODE || '').trim());
  const sessionSecret =
    options?.sessionSecret ??
    (process.env.ADMIN_SESSION_SECRET || crypto.randomBytes(32).toString('hex'));

  let claimedHash: string | null = null;
  const revokedJtis = new Set<string>();

  const getStatus = (): { mode: AuthMode; configured: boolean } => {
    const envCode = getEnvCode();
    if (envCode.length > 0) {
      return { mode: 'env', configured: true };
    }
    if (claimedHash) {
      return { mode: 'claimed', configured: true };
    }
    return { mode: 'setup', configured: false };
  };

  const claimInitialCode = (code: string) => {
    const status = getStatus();
    if (status.mode !== 'setup') {
      return {
        ok: false as const,
        status: 409,
        error: 'An owner access code is already configured. Please sign in.',
      };
    }

    const trimmed = typeof code === 'string' ? code.trim() : '';
    if (trimmed.length < 4 || trimmed.length > 128) {
      return {
        ok: false as const,
        status: 400,
        error: 'Access code must be between 4 and 128 characters.',
      };
    }

    claimedHash = hashAccessCode(trimmed);
    const session = signSessionToken(sessionSecret);
    return { ok: true as const, ...session };
  };

  const login = (code: string) => {
    const status = getStatus();
    if (status.mode === 'setup') {
      return {
        ok: false as const,
        status: 409,
        error: 'Owner access code is not set yet. Complete initial setup first.',
      };
    }

    const trimmed = typeof code === 'string' ? code.trim() : '';
    if (!trimmed) {
      return {
        ok: false as const,
        status: 400,
        error: 'Please enter your special access code.',
      };
    }

    let valid = false;
    if (status.mode === 'env') {
      valid = timingSafeCompareCode(trimmed, getEnvCode());
    } else if (claimedHash) {
      valid = verifyAccessCodeHash(trimmed, claimedHash);
    }

    if (!valid) {
      return {
        ok: false as const,
        status: 401,
        error: 'Invalid access code. Please check your code and try again.',
      };
    }

    const session = signSessionToken(sessionSecret);
    return { ok: true as const, ...session };
  };

  const extractBearerToken = (authHeader: string | undefined): string | null => {
    if (!authHeader || typeof authHeader !== 'string') return null;
    if (!authHeader.startsWith('Bearer ')) return null;
    return authHeader.slice('Bearer '.length).trim() || null;
  };

  const verifyBearerHeader = (authHeader: string | undefined): SessionPayload | null => {
    const token = extractBearerToken(authHeader);
    if (!token) return null;
    const payload = verifySessionToken(token, sessionSecret);
    if (!payload) return null;
    if (revokedJtis.has(payload.jti)) return null;
    return payload;
  };

  const revokeBearerHeader = (authHeader: string | undefined): void => {
    const token = extractBearerToken(authHeader);
    if (!token) return;
    const payload = verifySessionToken(token, sessionSecret);
    if (payload) {
      revokedJtis.add(payload.jti);
    }
  };

  return {
    getStatus,
    claimInitialCode,
    login,
    verifyBearerHeader,
    revokeBearerHeader,
  };
}
