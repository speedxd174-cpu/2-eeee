export type ProductCategory =
  | "Women's Dresses"
  | "Casual Wear"
  | "Traditional Wear"
  | "Party Wear"
  | "Tops & Shirts"
  | "New Arrivals";

export interface ProductColor {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  priceNpr: number;
  description: string;
  fabricCare: string;
  imageUrl: string;
  imageAlt: string;
  sizes: string[];
  colors: ProductColor[];
  isNewArrival: boolean;
  isFeatured: boolean;
  inStock: boolean;
  createdAt: string;
}

export interface CartItem {
  key: string; // productId::size::colorName
  productId: string;
  name: string;
  category: ProductCategory;
  priceNpr: number;
  imageUrl: string;
  selectedSize: string;
  selectedColor: ProductColor;
  quantity: number;
}

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'completed';

export interface OrderItem {
  productId: string;
  productName: string;
  priceNpr: number;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
  lineTotalNpr: number;
  imageUrl: string;
}

export interface Order {
  id: string;
  createdAt: string;
  customerName: string;
  phoneNumber: string;
  deliveryAddress: string;
  cityDistrict: string;
  instructions: string;
  items: OrderItem[];
  subtotalNpr: number;
  deliveryFeeNpr: number;
  totalNpr: number;
  status: OrderStatus;
}

export interface CheckoutFormData {
  customerName: string;
  phoneNumber: string;
  deliveryAddress: string;
  cityDistrict: string;
  instructions: string;
}

export type CheckoutValidationErrors = Partial<Record<keyof CheckoutFormData, string>>;

export type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'newest';

export interface StoreRepository {
  getProducts: () => Product[];
  saveProducts: (products: Product[]) => void;
  upsertProduct: (product: Product) => Product[];
  deleteProduct: (productId: string) => Product[];
  getOrders: () => Order[];
  createOrder: (order: Order) => Order[];
  updateOrderStatus: (orderId: string, status: OrderStatus) => Order[];
  resetDemoData: () => { products: Product[]; orders: Order[] };
}
