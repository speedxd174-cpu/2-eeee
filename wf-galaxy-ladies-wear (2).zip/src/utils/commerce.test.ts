import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildWhatsAppUrl,
  calculateCartTotals,
  computeOrderMetrics,
  filterAndSortProducts,
  formatNPR,
  generateOrderId,
  validateCheckoutForm,
} from './commerce';
import { SEED_ORDERS, SEED_PRODUCTS } from '../data/seedProducts';
import { CartItem } from '../types/store';

test('formatNPR formats Nepali Rupees clearly without decimals', () => {
  assert.equal(formatNPR(2850), 'NPR 2,850');
  assert.equal(formatNPR(0), 'NPR 0');
});

test('calculateCartTotals computes subtotal, free delivery threshold, and total', () => {
  const belowThreshold: CartItem[] = [
    {
      key: 'wfg-top-04::M::Pearl Ivory',
      productId: 'wfg-top-04',
      name: 'Elena Pearl Satin Wrap Blouse',
      category: 'Tops & Shirts',
      priceNpr: 1750,
      imageUrl: '/test.jpg',
      selectedSize: 'M',
      selectedColor: { name: 'Pearl Ivory', hex: '#F4EFE8' },
      quantity: 1,
    },
  ];

  const t1 = calculateCartTotals(belowThreshold);
  assert.equal(t1.itemCount, 1);
  assert.equal(t1.subtotalNpr, 1750);
  assert.equal(t1.deliveryFeeNpr, 150);
  assert.equal(t1.totalNpr, 1900);
  assert.equal(t1.amountToFreeDelivery, 1750);

  const aboveThreshold: CartItem[] = [
    { ...belowThreshold[0], quantity: 2 },
  ];
  const t2 = calculateCartTotals(aboveThreshold);
  assert.equal(t2.itemCount, 2);
  assert.equal(t2.subtotalNpr, 3500);
  assert.equal(t2.deliveryFeeNpr, 0);
  assert.equal(t2.totalNpr, 3500);
  assert.equal(t2.amountToFreeDelivery, 0);
});

test('validateCheckoutForm rejects empty fields and invalid Nepal phone numbers', () => {
  const emptyErrors = validateCheckoutForm({
    customerName: '',
    phoneNumber: '123',
    deliveryAddress: 'ab',
    cityDistrict: '',
    instructions: '',
  });
  assert.ok(emptyErrors.customerName);
  assert.ok(emptyErrors.phoneNumber);
  assert.ok(emptyErrors.deliveryAddress);
  assert.ok(emptyErrors.cityDistrict);

  const validErrors = validateCheckoutForm({
    customerName: 'Sita Sharma',
    phoneNumber: '+977 976-7740629',
    deliveryAddress: 'Amarpath, Ward 4, Butwal',
    cityDistrict: 'Butwal',
    instructions: 'Call on arrival',
  });
  assert.deepEqual(validErrors, {});
});

test('generateOrderId follows WFG-YYMM-XXXX format', () => {
  const id = generateOrderId(new Date('2026-11-25T10:00:00Z'));
  assert.match(id, /^WFG-2611-\d{4}$/);
});

test('buildWhatsAppUrl encodes message with official business WhatsApp number', () => {
  const url = buildWhatsAppUrl('Hello WF Galaxy');
  assert.equal(url, 'https://wa.me/9779767740629?text=Hello%20WF%20Galaxy');
});

test('filterAndSortProducts filters by category, search term, and sorts by price', () => {
  const traditional = filterAndSortProducts(SEED_PRODUCTS, {
    category: 'Traditional Wear',
  });
  assert.equal(traditional.length, 2);

  const searchMatches = filterAndSortProducts(SEED_PRODUCTS, {
    search: 'kurta',
  });
  assert.equal(searchMatches.length, 1);
  assert.equal(searchMatches[0].id, 'wfg-trad-02');

  const sortedAsc = filterAndSortProducts(SEED_PRODUCTS, {
    sort: 'price-asc',
  });
  assert.ok(sortedAsc[0].priceNpr <= sortedAsc[1].priceNpr);
});

test('computeOrderMetrics summarizes seed orders accurately', () => {
  const metrics = computeOrderMetrics(SEED_ORDERS);
  assert.equal(metrics.totalOrders, 3);
  assert.equal(metrics.pendingOrders, 1);
  assert.equal(metrics.completedOrders, 1);
  assert.equal(metrics.totalOrderValueNpr, 5200 + 3000 + 4650);
});
