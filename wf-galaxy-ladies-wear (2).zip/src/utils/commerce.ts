import { BUSINESS_INFO } from '../data/seedProducts';
import {
  CartItem,
  CheckoutFormData,
  CheckoutValidationErrors,
  Order,
  Product,
  ProductCategory,
  SortOption,
} from '../types/store';

export function formatNPR(amount: number): string {
  const safeAmount = Math.max(0, Math.round(Number.isFinite(amount) ? amount : 0));
  return `NPR ${safeAmount.toLocaleString('en-US')}`;
}

export function buildCartItemKey(productId: string, size: string, colorName: string): string {
  return `${productId}::${size}::${colorName}`;
}

export function calculateCartTotals(items: CartItem[]): {
  itemCount: number;
  subtotalNpr: number;
  deliveryFeeNpr: number;
  totalNpr: number;
  amountToFreeDelivery: number;
} {
  const itemCount = items.reduce((sum, item) => sum + Math.max(0, item.quantity), 0);
  const subtotalNpr = items.reduce(
    (sum, item) => sum + Math.max(0, item.priceNpr) * Math.max(0, item.quantity),
    0,
  );
  const deliveryFeeNpr =
    subtotalNpr === 0 || subtotalNpr >= BUSINESS_INFO.freeDeliveryThresholdNpr
      ? 0
      : BUSINESS_INFO.standardDeliveryFeeNpr;
  const totalNpr = subtotalNpr + deliveryFeeNpr;
  const amountToFreeDelivery = Math.max(
    0,
    BUSINESS_INFO.freeDeliveryThresholdNpr - subtotalNpr,
  );

  return {
    itemCount,
    subtotalNpr,
    deliveryFeeNpr,
    totalNpr,
    amountToFreeDelivery,
  };
}

export function validateCheckoutForm(data: CheckoutFormData): CheckoutValidationErrors {
  const errors: CheckoutValidationErrors = {};

  if (!data.customerName || data.customerName.trim().length < 2) {
    errors.customerName = 'Please enter your full name (at least 2 characters).';
  }

  const digits = (data.phoneNumber || '').replace(/\D/g, '');
  const normalized = digits.startsWith('977') ? digits.slice(3) : digits;
  if (normalized.length < 9 || normalized.length > 10 || !/^(9[678]\d{8}|0\d{8,9})$/.test(normalized)) {
    errors.phoneNumber = 'Enter a valid Nepal phone number (e.g., 98XXXXXXXX or +977 976-7740629).';
  }

  if (!data.deliveryAddress || data.deliveryAddress.trim().length < 5) {
    errors.deliveryAddress = 'Please enter your complete street/tole delivery address.';
  }

  if (!data.cityDistrict || data.cityDistrict.trim().length < 2) {
    errors.cityDistrict = 'Please enter your city or district (e.g., Butwal, Kathmandu).';
  }

  return errors;
}

export function generateOrderId(now: Date = new Date()): string {
  const yy = String(now.getFullYear()).slice(-2);
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const rand = String(Math.floor(1000 + Math.random() * 9000));
  return `WFG-${yy}${mm}-${rand}`;
}

export function normalizeWhatsAppDigits(rawPhone: string): string {
  const digits = rawPhone.replace(/\D/g, '');
  if (!digits) return BUSINESS_INFO.whatsappDigits;
  if (digits.startsWith('977')) return digits;
  if (digits.length === 10 && digits.startsWith('9')) return `977${digits}`;
  if (digits.length === 11 && digits.startsWith('0')) return `977${digits.slice(1)}`;
  return digits;
}

export function buildWhatsAppUrl(message: string, targetPhoneDigits: string = BUSINESS_INFO.whatsappDigits): string {
  const cleanDigits = normalizeWhatsAppDigits(targetPhoneDigits);
  return `https://wa.me/${cleanDigits}?text=${encodeURIComponent(message)}`;
}

export function buildProductInquiryMessage(
  product: Product,
  selectedSize?: string,
  selectedColorName?: string,
): string {
  const sizePart = selectedSize ? ` | Size: ${selectedSize}` : '';
  const colorPart = selectedColorName ? ` | Color: ${selectedColorName}` : '';
  return `Hello WF Galaxy Ladies Wear! I would like to inquire/order:\n• Product: ${product.name}\n• Price: ${formatNPR(product.priceNpr)}${sizePart}${colorPart}\n\nPlease let me know availability and delivery details.`;
}

export function buildOrderWhatsAppMessage(order: Order): string {
  const itemsText = order.items
    .map(
      (item, idx) =>
        `${idx + 1}. ${item.productName} (${item.selectedSize}, ${item.selectedColor}) x${item.quantity} — ${formatNPR(item.lineTotalNpr)}`,
    )
    .join('\n');

  return [
    `Hello WF Galaxy Ladies Wear! I placed an order on your website:`,
    `Order ID: ${order.id}`,
    `Customer: ${order.customerName}`,
    `Phone: ${order.phoneNumber}`,
    `Delivery: ${order.deliveryAddress}, ${order.cityDistrict}`,
    '',
    `Items:`,
    itemsText,
    '',
    `Total Amount: ${formatNPR(order.totalNpr)}`,
    order.instructions ? `Notes: ${order.instructions}` : '',
  ]
    .filter(Boolean)
    .join('\n');
}

export function buildAdminCustomerWhatsAppMessage(order: Order): string {
  return `Namaste ${order.customerName}, thank you for shopping with WF Galaxy Ladies Wear (Butwal)! Your order ${order.id} (${formatNPR(order.totalNpr)}) is currently marked as "${order.status.toUpperCase()}". Please reply if you need any assistance.`;
}

export function filterAndSortProducts(
  products: Product[],
  options: {
    search?: string;
    category?: 'All' | ProductCategory;
    sort?: SortOption;
  },
): Product[] {
  const search = (options.search || '').trim().toLowerCase();
  const category = options.category || 'All';
  const sort = options.sort || 'featured';

  const filtered = products.filter((product) => {
    const matchesCategory =
      category === 'All'
        ? true
        : category === 'New Arrivals'
          ? product.category === 'New Arrivals' || product.isNewArrival
          : product.category === category;

    if (!matchesCategory) return false;
    if (!search) return true;

    const haystack = [
      product.name,
      product.category,
      product.description,
      ...product.colors.map((c) => c.name),
    ]
      .join(' ')
      .toLowerCase();

    return haystack.includes(search);
  });

  const sorted = [...filtered];
  if (sort === 'price-asc') {
    sorted.sort((a, b) => a.priceNpr - b.priceNpr);
  } else if (sort === 'price-desc') {
    sorted.sort((a, b) => b.priceNpr - a.priceNpr);
  } else if (sort === 'newest') {
    sorted.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } else {
    sorted.sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured));
  }

  return sorted;
}

export function computeOrderMetrics(orders: Order[]): {
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  totalOrderValueNpr: number;
} {
  return orders.reduce(
    (acc, order) => {
      acc.totalOrders += 1;
      if (order.status === 'pending') acc.pendingOrders += 1;
      if (order.status === 'completed') acc.completedOrders += 1;
      acc.totalOrderValueNpr += order.totalNpr;
      return acc;
    },
    {
      totalOrders: 0,
      pendingOrders: 0,
      completedOrders: 0,
      totalOrderValueNpr: 0,
    },
  );
}
