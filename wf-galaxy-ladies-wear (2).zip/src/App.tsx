import React, { useEffect, useMemo, useState } from 'react';
import { Check } from 'lucide-react';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminLoginPage } from './components/AdminLoginPage';
import { CartDrawer } from './components/CartDrawer';
import { CategoryStrip } from './components/CategoryStrip';
import { CheckoutPage, OrderConfirmationView } from './components/CheckoutPage';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { AppRoute, Navbar } from './components/Navbar';
import { ProductCatalog } from './components/ProductCatalog';
import { ProductDetailView } from './components/ProductDetailView';
import { WhyChooseAndContact } from './components/WhyChooseAndContact';
import { BUSINESS_INFO } from './data/seedProducts';
import {
  loadPersistedCart,
  savePersistedCart,
  storeRepository,
} from './services/storageRepository';
import {
  CartItem,
  Order,
  OrderStatus,
  Product,
  ProductCategory,
  ProductColor,
  SortOption,
} from './types/store';
import { buildCartItemKey, calculateCartTotals } from './utils/commerce';

function parsePathToRoute(pathname: string): AppRoute {
  const clean = pathname.replace(/\/+$/, '') || '/';
  if (clean === '/login') return { name: 'login' };
  if (clean === '/admin') return { name: 'admin' };
  if (clean === '/shop') return { name: 'shop' };
  if (clean === '/new-arrivals') return { name: 'new-arrivals' };
  if (clean === '/collections') return { name: 'collections' };
  if (clean === '/contact') return { name: 'contact' };
  if (clean === '/checkout') return { name: 'checkout' };
  if (clean.startsWith('/product/')) {
    return { name: 'product', productId: decodeURIComponent(clean.slice('/product/'.length)) };
  }
  if (clean.startsWith('/order-confirmation/')) {
    return {
      name: 'order-confirmation',
      orderId: decodeURIComponent(clean.slice('/order-confirmation/'.length)),
    };
  }
  return { name: 'home' };
}

function routeToPath(route: AppRoute): string {
  switch (route.name) {
    case 'home':
      return '/';
    case 'shop':
      return '/shop';
    case 'new-arrivals':
      return '/new-arrivals';
    case 'collections':
      return '/collections';
    case 'contact':
      return '/contact';
    case 'checkout':
      return '/checkout';
    case 'login':
      return '/login';
    case 'admin':
      return '/admin';
    case 'product':
      return `/product/${encodeURIComponent(route.productId)}`;
    case 'order-confirmation':
      return `/order-confirmation/${encodeURIComponent(route.orderId)}`;
  }
}

export default function App() {
  const [route, setRoute] = useState<AppRoute>(() =>
    typeof window !== 'undefined' ? parsePathToRoute(window.location.pathname) : { name: 'home' },
  );
  const [products, setProducts] = useState<Product[]>(() => storeRepository.getProducts());
  const [orders, setOrders] = useState<Order[]>(() => storeRepository.getOrders());
  const [cart, setCart] = useState<CartItem[]>(() => loadPersistedCart<CartItem>());

  // Admin session token held strictly in memory (never localStorage/sessionStorage)
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [adminVerified, setAdminVerified] = useState<boolean>(false);

  const [selectedCategory, setSelectedCategory] = useState<'All' | ProductCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('featured');

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const timer = window.setTimeout(() => setToastMessage(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  useEffect(() => {
    savePersistedCart(cart);
  }, [cart]);

  useEffect(() => {
    const onPopState = () => {
      setRoute(parsePathToRoute(window.location.pathname));
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    let cancelled = false;
    if (!adminToken) {
      setAdminVerified(false);
      return;
    }

    fetch('/api/admin/auth/verify', {
      headers: { Authorization: `Bearer ${adminToken}` },
    })
      .then((res) => {
        if (!cancelled) {
          if (res.ok) {
            setAdminVerified(true);
          } else {
            setAdminToken(null);
            setAdminVerified(false);
          }
        }
      })
      .catch(() => {
        if (!cancelled) {
          setAdminVerified(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [adminToken, route.name]);

  useEffect(() => {
    const titles: Record<AppRoute['name'], string> = {
      home: `${BUSINESS_INFO.name} — Women's Clothing Store in Butwal, Nepal`,
      shop: `Shop Collection — ${BUSINESS_INFO.name} | Ladies Wear in Butwal`,
      'new-arrivals': `New Arrivals — ${BUSINESS_INFO.name} | Women's Fashion Nepal`,
      collections: `Collections — ${BUSINESS_INFO.name} | Dresses, Kurtas & Party Wear`,
      contact: `Contact & WhatsApp Orders — ${BUSINESS_INFO.name} Butwal`,
      checkout: `Checkout — ${BUSINESS_INFO.name}`,
      'order-confirmation': `Order Confirmed — ${BUSINESS_INFO.name}`,
      login: `Private Access — ${BUSINESS_INFO.name}`,
      admin: adminVerified
        ? `Owner Admin Dashboard — ${BUSINESS_INFO.name}`
        : `Private Access — ${BUSINESS_INFO.name}`,
      product: `${BUSINESS_INFO.name} — Product Details`,
    };

    if (route.name === 'product') {
      const found = products.find((p) => p.id === route.productId);
      document.title = found
        ? `${found.name} — ${BUSINESS_INFO.name}`
        : titles.product;
    } else {
      document.title = titles[route.name];
    }

    // Prevent search indexing of hidden owner login/admin routes
    let robotsMeta = document.querySelector('meta[name="robots"]');
    if (route.name === 'login' || route.name === 'admin') {
      if (!robotsMeta) {
        robotsMeta = document.createElement('meta');
        robotsMeta.setAttribute('name', 'robots');
        document.head.appendChild(robotsMeta);
      }
      robotsMeta.setAttribute('content', 'noindex, nofollow');
    } else if (robotsMeta) {
      robotsMeta.remove();
    }
  }, [route, products, adminVerified]);

  const navigate = (nextRoute: AppRoute, options?: { scrollToId?: string }) => {
    const targetPath = routeToPath(nextRoute);
    if (window.location.pathname !== targetPath) {
      window.history.pushState({}, '', targetPath);
    }
    setRoute(nextRoute);
    setQuickViewProduct(null);

    if (nextRoute.name === 'new-arrivals') {
      setSelectedCategory('New Arrivals');
    } else if (nextRoute.name === 'home') {
      setSelectedCategory('All');
    }

    window.setTimeout(() => {
      if (options?.scrollToId) {
        document.getElementById(options.scrollToId)?.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 30);
  };

  const cartTotals = useMemo(() => calculateCartTotals(cart), [cart]);

  const handleAddToCart = (
    product: Product,
    size: string,
    color: ProductColor,
    quantity: number,
  ) => {
    const key = buildCartItemKey(product.id, size, color.name);
    setCart((prev) => {
      const existing = prev.find((item) => item.key === key);
      if (existing) {
        return prev.map((item) =>
          item.key === key ? { ...item, quantity: item.quantity + quantity } : item,
        );
      }
      return [
        ...prev,
        {
          key,
          productId: product.id,
          name: product.name,
          category: product.category,
          priceNpr: product.priceNpr,
          imageUrl: product.imageUrl,
          selectedSize: size,
          selectedColor: color,
          quantity,
        },
      ];
    });
    setIsCartOpen(true);
    showToast(`Added "${product.name}" (${size}) to your bag.`);
  };

  const handleUpdateCartQuantity = (key: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.key === key ? { ...item, quantity: item.quantity + delta } : item,
        )
        .filter((item) => item.quantity > 0),
    );
  };

  const handleRemoveCartItem = (key: string) => {
    setCart((prev) => prev.filter((item) => item.key !== key));
  };

  const handleSubmitOrder = (newOrder: Order) => {
    const updatedOrders = storeRepository.createOrder(newOrder);
    setOrders(updatedOrders);
    setCart([]);
    navigate({ name: 'order-confirmation', orderId: newOrder.id });
    showToast(`Order ${newOrder.id} placed successfully!`);
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    const updatedOrders = storeRepository.updateOrderStatus(orderId, status);
    setOrders(updatedOrders);
    showToast(`Order ${orderId} marked as ${status}.`);
  };

  const handleUpsertProduct = (product: Product) => {
    const updatedProducts = storeRepository.upsertProduct(product);
    setProducts(updatedProducts);
    showToast(`Saved "${product.name}".`);
  };

  const handleDeleteProduct = (productId: string) => {
    const updatedProducts = storeRepository.deleteProduct(productId);
    setProducts(updatedProducts);
    showToast('Product removed from catalog.');
  };

  const handleResetDemoData = () => {
    const reset = storeRepository.resetDemoData();
    setProducts(reset.products);
    setOrders(reset.orders);
    showToast('Demo catalog and sample orders restored.');
  };

  const handleOwnerAuthenticated = (token: string) => {
    setAdminToken(token);
    setAdminVerified(true);
    navigate({ name: 'admin' });
    showToast('Admin dashboard unlocked.');
  };

  const handleOwnerLogout = async () => {
    if (adminToken) {
      try {
        await fetch('/api/admin/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${adminToken}` },
        });
      } catch {
        // Ignore network errors when clearing local session
      }
    }
    setAdminToken(null);
    setAdminVerified(false);
    navigate({ name: 'home' });
    showToast('Admin session locked.');
  };

  const activeProductForRoute =
    route.name === 'product'
      ? products.find((p) => p.id === route.productId)
      : undefined;

  const activeOrderForRoute =
    route.name === 'order-confirmation'
      ? orders.find((o) => o.id === route.orderId)
      : undefined;

  const isPrivateRoute = route.name === 'login' || route.name === 'admin';

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFCFD] text-[#1F1619]">
      <Navbar
        currentRoute={route}
        cartCount={cartTotals.itemCount}
        searchQuery={searchQuery}
        onSearchChange={(q) => setSearchQuery(q)}
        onNavigate={(r) => {
          if (r.name === 'contact') {
            navigate({ name: 'home' }, { scrollToId: 'contact-section' });
          } else {
            navigate(r);
          }
        }}
        onOpenCart={() => setIsCartOpen(true)}
      />

      <div className="flex-1">
        {route.name === 'home' && (
          <main>
            <HeroSection
              onShopCollection={() => {
                setSelectedCategory('All');
                navigate({ name: 'shop' });
              }}
              onExploreNewArrivals={() => {
                setSelectedCategory('New Arrivals');
                navigate({ name: 'new-arrivals' });
              }}
            />

            <CategoryStrip
              products={products}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                document.getElementById('catalog-section')?.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            <ProductCatalog
              products={products}
              selectedCategory={selectedCategory}
              searchQuery={searchQuery}
              sortBy={sortBy}
              onCategoryChange={setSelectedCategory}
              onSearchChange={setSearchQuery}
              onSortChange={setSortBy}
              onQuickView={(prod) => setQuickViewProduct(prod)}
              onQuickAddToCart={handleAddToCart}
            />

            <WhyChooseAndContact />
          </main>
        )}

        {(route.name === 'shop' || route.name === 'new-arrivals') && (
          <main>
            <ProductCatalog
              products={products}
              selectedCategory={route.name === 'new-arrivals' ? 'New Arrivals' : selectedCategory}
              searchQuery={searchQuery}
              sortBy={sortBy}
              onCategoryChange={(cat) => {
                setSelectedCategory(cat);
                if (route.name === 'new-arrivals' && cat !== 'New Arrivals') {
                  navigate({ name: 'shop' });
                }
              }}
              onSearchChange={setSearchQuery}
              onSortChange={setSortBy}
              onQuickView={(prod) => navigate({ name: 'product', productId: prod.id })}
              onQuickAddToCart={handleAddToCart}
              title={route.name === 'new-arrivals' ? 'New Arrivals' : 'Shop All Styles'}
            />
          </main>
        )}

        {route.name === 'collections' && (
          <main>
            <CategoryStrip
              products={products}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                navigate({ name: 'shop' });
              }}
            />
            <ProductCatalog
              products={products}
              selectedCategory={selectedCategory}
              searchQuery={searchQuery}
              sortBy={sortBy}
              onCategoryChange={setSelectedCategory}
              onSearchChange={setSearchQuery}
              onSortChange={setSortBy}
              onQuickView={(prod) => navigate({ name: 'product', productId: prod.id })}
              onQuickAddToCart={handleAddToCart}
              title="All Collections"
            />
          </main>
        )}

        {route.name === 'product' && activeProductForRoute && (
          <ProductDetailView
            product={activeProductForRoute}
            onClose={() => navigate({ name: 'shop' })}
            onAddToCart={handleAddToCart}
          />
        )}

        {route.name === 'product' && !activeProductForRoute && (
          <main className="max-w-[760px] mx-auto px-4 py-16 text-center">
            <h1 className="font-display text-3xl font-semibold">Product not found</h1>
            <button
              type="button"
              onClick={() => navigate({ name: 'shop' })}
              className="mt-5 px-5 py-2.5 rounded-md bg-[#7A1C3A] text-white text-xs font-medium cursor-pointer"
            >
              Browse Shop
            </button>
          </main>
        )}

        {route.name === 'checkout' && (
          <CheckoutPage
            items={cart}
            onSubmitOrder={handleSubmitOrder}
            onBackToShop={() => navigate({ name: 'shop' })}
          />
        )}

        {route.name === 'order-confirmation' && (
          <OrderConfirmationView
            order={activeOrderForRoute}
            onContinueShopping={() => navigate({ name: 'shop' })}
          />
        )}

        {isPrivateRoute && !adminVerified && (
          <AdminLoginPage
            onAuthenticated={handleOwnerAuthenticated}
            onBackToStore={() => navigate({ name: 'home' })}
          />
        )}

        {isPrivateRoute && adminVerified && (
          <AdminDashboard
            products={products}
            orders={orders}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onUpsertProduct={handleUpsertProduct}
            onDeleteProduct={handleDeleteProduct}
            onResetDemoData={handleResetDemoData}
            onBackToStore={() => navigate({ name: 'home' })}
            onLogout={handleOwnerLogout}
          />
        )}
      </div>

      {!isPrivateRoute && <Footer onNavigate={(r) => navigate(r)} />}

      {!isPrivateRoute && <FloatingWhatsApp />}

      {/* Quick View Modal */}
      {quickViewProduct && (
        <ProductDetailView
          product={quickViewProduct}
          isModal
          onClose={() => setQuickViewProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* Slide-Over Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        items={cart}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          navigate({ name: 'checkout' });
        }}
      />

      {/* Non-blocking Toast Feedback */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 left-5 z-50 inline-flex items-center gap-2 px-4 py-3 rounded-md bg-[#1F1619] text-white text-xs font-medium shadow-lg"
        >
          <Check className="w-4 h-4 text-[#DFCFA8] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
