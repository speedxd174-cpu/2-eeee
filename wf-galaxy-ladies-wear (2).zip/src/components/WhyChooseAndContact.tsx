import React from 'react';
import { MapPin, MessageCircle, Phone, Sparkles, Truck } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import { buildWhatsAppUrl } from '../utils/commerce';

const PILLARS = [
  {
    number: '01',
    title: 'Quality Fashion',
    description:
      'Carefully selected fabrics, refined tailoring, and comfortable fits suited for every season in Nepal.',
  },
  {
    number: '02',
    title: 'Affordable Prices',
    description:
      'Boutique-grade women’s wear priced fairly in NPR so contemporary style stays accessible.',
  },
  {
    number: '03',
    title: 'Latest Collections',
    description:
      'Fresh arrivals across dresses, festive kurtas, sarees, casual co-ords, and evening party wear.',
  },
  {
    number: '04',
    title: 'Delivery Across Nepal',
    description:
      'Fast dispatch from our Butwal store to Rupandehi, Kathmandu Valley, Pokhara, Chitwan, and nationwide.',
  },
];

export function WhyChooseAndContact() {
  const whatsappUrl = buildWhatsAppUrl(
    'Namaste WF Galaxy Ladies Wear! I would like style recommendations and ordering assistance.',
  );

  return (
    <>
      {/* Why Choose Us */}
      <section className="bg-[#FDF5F7] border-y border-[#EADCE1]">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14">
          <div className="max-w-xl mb-10">
            <p className="text-xs font-medium text-[#7A1C3A] tracking-wide mb-1.5">
              Why Choose Us
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619]">
              Wear Confidence, Every Day
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {PILLARS.map((pillar) => (
              <div
                key={pillar.number}
                className="bg-white border border-[#EADCE1] rounded-lg p-6 space-y-2.5"
              >
                <span className="font-mono text-xs font-medium text-[#B89047]">
                  {pillar.number}.
                </span>
                <h3 className="text-base font-semibold text-[#1F1619]">{pillar.title}</h3>
                <p className="text-sm text-[#645359] leading-relaxed">{pillar.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Customer Experience & Butwal Contact Section */}
      <section id="contact-section" className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14">
        <div className="bg-white border border-[#EADCE1] rounded-lg p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <p className="text-xs font-medium text-[#7A1C3A] tracking-wide">
              Customer Experience &amp; Boutique Support
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619]">
              Easy Online Ordering &amp; Direct WhatsApp Assistance
            </h2>
            <p className="text-sm sm:text-base text-[#645359] leading-relaxed max-w-2xl">
              Need help picking your size, checking fabric drape, or confirming delivery timing in
              Butwal or outside the valley? Message WF Galaxy Ladies Wear directly on WhatsApp for
              personal styling guidance and instant order support.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 text-xs text-[#645359]">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#7A1C3A] shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-[#1F1619]">Location</p>
                  <p>{BUSINESS_INFO.location}</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-[#7A1C3A] shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-[#1F1619]">WhatsApp</p>
                  <p className="tabular-nums">{BUSINESS_INFO.whatsappDisplay}</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Truck className="w-4 h-4 text-[#7A1C3A] shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-[#1F1619]">Nationwide Delivery</p>
                  <p>{BUSINESS_INFO.deliveryNote}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#FDF5F7] border border-[#EADCE1] rounded-lg p-6 space-y-4">
            <div className="flex items-center gap-2 text-xs font-medium text-[#7A1C3A]">
              <Sparkles className="w-4 h-4" />
              <span>Personal Styling &amp; Quick Inquiries</span>
            </div>
            <h3 className="font-display text-2xl font-semibold text-[#1F1619]">
              Message WF Galaxy on WhatsApp
            </h3>
            <p className="text-xs text-[#645359] leading-relaxed">
              DM to order and inquire about colors, sizing, or Cash on Delivery availability across
              Nepal.
            </p>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-sm font-medium transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Chat on WhatsApp ({BUSINESS_INFO.whatsappDisplay})</span>
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
