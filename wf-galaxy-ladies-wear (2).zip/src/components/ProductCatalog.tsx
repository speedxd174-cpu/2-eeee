import React, { useMemo } from 'react';
import { Eye, Search, ShoppingBag, X } from 'lucide-react';
import { CATEGORIES } from '../data/seedProducts';
import { Product, ProductCategory, ProductColor, SortOption } from '../types/store';
import { filterAndSortProducts, formatNPR } from '../utils/commerce';
import { ProductImage } from './BrandLogo';

interface ProductCatalogProps {
  products: Product[];
  selectedCategory: 'All' | ProductCategory;
  searchQuery: string;
  sortBy: SortOption;
  onCategoryChange: (category: 'All' | ProductCategory) => void;
  onSearchChange: (query: string) => void;
  onSortChange: (sort: SortOption) => void;
  onQuickView: (product: Product) => void;
  onQuickAddToCart: (
    product: Product,
    size: string,
    color: ProductColor,
    quantity: number,
  ) => void;
  title?: string;
  subtitle?: string;
}

export function ProductCatalog({
  products,
  selectedCategory,
  searchQuery,
  sortBy,
  onCategoryChange,
  onSearchChange,
  onSortChange,
  onQuickView,
  onQuickAddToCart,
  title = 'Featured Collection',
  subtitle = 'Sample catalog items and NPR prices are demo placeholders that you can edit or replace anytime from the Owner Admin Dashboard.',
}: ProductCatalogProps) {
  const filteredProducts = useMemo(
    () =>
      filterAndSortProducts(products, {
        search: searchQuery,
        category: selectedCategory,
        sort: sortBy,
      }),
    [products, searchQuery, selectedCategory, sortBy],
  );

  const filterTabs: ('All' | ProductCategory)[] = ['All', ...CATEGORIES];

  return (
    <section id="catalog-section" className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <p className="text-xs font-medium text-[#7A1C3A] tracking-wide mb-1.5">
            WF Galaxy Ladies Wear · Butwal
          </p>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619]">
            {title}
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-[#645359] max-w-md leading-relaxed">{subtitle}</p>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col gap-4 pb-6 mb-8 border-b border-[#EADCE1]">
        {/* Category Tabs */}
        <div className="flex flex-wrap items-center gap-2">
          {filterTabs.map((tab) => {
            const active = selectedCategory === tab;
            return (
              <button
                key={tab}
                type="button"
                aria-pressed={active}
                onClick={() => onCategoryChange(tab)}
                className={`px-3.5 py-2 rounded-md text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#7A1C3A] text-white'
                    : 'bg-[#FDF5F7] text-[#645359] hover:text-[#1F1619] hover:bg-[#F8E8EE]'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {/* Search + Result Count + Sort Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 sm:max-w-sm">
            <Search className="w-4 h-4 text-[#645359] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <label htmlFor="catalog-search-input" className="sr-only">
              Search products by name
            </label>
            <input
              id="catalog-search-input"
              type="search"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search by name or style..."
              className="w-full pl-9 pr-8 py-2 bg-white border border-[#EADCE1] rounded-md text-sm text-[#1F1619] placeholder:text-[#645359]/70 focus:outline-none focus:border-[#7A1C3A]"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                aria-label="Clear search query"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#645359] hover:text-[#1F1619] cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
            <span className="text-xs text-[#645359] tabular-nums">
              Showing {filteredProducts.length} {filteredProducts.length === 1 ? 'style' : 'styles'}
            </span>
            <div className="flex items-center gap-2">
              <label htmlFor="catalog-sort" className="text-xs text-[#645359] whitespace-nowrap">
                Sort by
              </label>
              <select
                id="catalog-sort"
                value={sortBy}
                onChange={(e) => onSortChange(e.target.value as SortOption)}
                className="bg-white border border-[#EADCE1] rounded-md px-3 py-2 text-xs font-medium text-[#1F1619] focus:outline-none focus:border-[#7A1C3A] cursor-pointer"
              >
                <option value="featured">Featured</option>
                <option value="newest">Newest</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Product Grid or Empty State */}
      {filteredProducts.length === 0 ? (
        <div className="py-16 px-6 text-center rounded-lg border border-[#EADCE1] bg-[#FDF5F7]">
          <p className="font-display text-2xl font-semibold text-[#1F1619]">
            No matching outfits found
          </p>
          <p className="text-sm text-[#645359] mt-2 max-w-md mx-auto">
            Try clearing your search or switching to another category to view all available styles.
          </p>
          <button
            type="button"
            onClick={() => {
              onSearchChange('');
              onCategoryChange('All');
            }}
            className="mt-5 px-5 py-2.5 rounded-md bg-[#7A1C3A] text-white text-xs font-medium hover:bg-[#5C122A] transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredProducts.map((product) => {
            const defaultSize = product.sizes[0] || 'M';
            const defaultColor = product.colors[0] || { name: 'Standard', hex: '#7A1C3A' };

            return (
              <article
                key={product.id}
                className="group flex flex-col bg-white border border-[#EADCE1] rounded-lg overflow-hidden transition-transform duration-150 hover:-translate-y-0.5 hover:shadow-sm"
              >
                {/* Portrait 3:4 Image */}
                <div className="relative aspect-[3/4] bg-[#FDF5F7] overflow-hidden">
                  <button
                    type="button"
                    onClick={() => onQuickView(product)}
                    aria-label={`View details for ${product.name}`}
                    className="w-full h-full block text-left cursor-pointer"
                  >
                    <ProductImage
                      src={product.imageUrl}
                      alt={product.imageAlt}
                      className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-[1.03]"
                      label={product.name}
                    />
                  </button>
                </div>

                {/* Clean Unboxed Metadata & Actions */}
                <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs text-[#645359]">
                      <span>{product.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {product.isNewArrival
                          ? 'New Arrival'
                          : product.inStock
                            ? 'In Stock'
                            : 'Made to Order'}
                      </span>
                    </div>

                    <h3 className="mt-1.5 text-base font-semibold text-[#1F1619] leading-snug">
                      <button
                        type="button"
                        onClick={() => onQuickView(product)}
                        className="text-left hover:text-[#7A1C3A] transition-colors cursor-pointer"
                      >
                        {product.name}
                      </button>
                    </h3>

                    <p className="mt-1.5 text-[15px] font-semibold text-[#7A1C3A] tabular-nums">
                      {formatNPR(product.priceNpr)}
                    </p>

                    {/* Sizes & Color Swatches */}
                    <div className="mt-3 pt-3 border-t border-[#EADCE1]/70 flex items-center justify-between gap-3 text-xs text-[#645359]">
                      <span className="truncate">
                        Sizes: {product.sizes.join(', ')}
                      </span>
                      <div className="flex items-center gap-1.5 shrink-0" title="Available colors">
                        {product.colors.slice(0, 4).map((color) => (
                          <span
                            key={color.name}
                            title={color.name}
                            className="w-3.5 h-3.5 rounded-full border border-black/15"
                            style={{ backgroundColor: color.hex }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Action Buttons */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => onQuickView(product)}
                      aria-label={`Quick view ${product.name}`}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-md border border-[#EADCE1] text-xs font-medium text-[#1F1619] hover:border-[#7A1C3A] hover:text-[#7A1C3A] transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Quick View</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onQuickAddToCart(product, defaultSize, defaultColor, 1)}
                      aria-label={`Add ${product.name} to cart`}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-xs font-medium transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Add to Cart</span>
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
