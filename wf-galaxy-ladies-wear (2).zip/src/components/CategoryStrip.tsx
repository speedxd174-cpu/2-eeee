import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { Product, ProductCategory } from '../types/store';
import { ProductImage } from './BrandLogo';

interface CategoryStripProps {
  products: Product[];
  onSelectCategory: (category: ProductCategory) => void;
}

const CATEGORY_CARDS: {
  category: ProductCategory;
  subtitle: string;
  imageUrl: string;
  alt: string;
}[] = [
  {
    category: "Women's Dresses",
    subtitle: 'Pleated midis & wrap silhouettes',
    imageUrl: '/images/dress_burgundy_midi_1795602446745.jpg',
    alt: "Women's Dresses collection at WF Galaxy Ladies Wear Butwal",
  },
  {
    category: 'Traditional Wear',
    subtitle: 'Chanderi kurtas & woven sarees',
    imageUrl: '/images/kurta_blush_embroidered_1795602447175.jpg',
    alt: 'Traditional Wear kurtas and sarees in Butwal, Nepal',
  },
  {
    category: 'Party Wear',
    subtitle: 'Evening satin gowns & occasion edits',
    imageUrl: '/images/gown_champagne_evening_1795602448875.jpg',
    alt: 'Party Wear gowns at WF Galaxy Ladies Wear Nepal',
  },
  {
    category: 'Casual Wear',
    subtitle: 'Breathable linen & everyday sets',
    imageUrl: '/images/co_ord_linen_casual_1795602449547.jpg',
    alt: 'Casual Wear linen outfits for women in Nepal',
  },
  {
    category: 'Tops & Shirts',
    subtitle: 'Satin wrap blouses & tailored tops',
    imageUrl: '/images/top_silk_ivory_blouse_1795602447997.jpg',
    alt: 'Tops and Shirts women fashion Butwal',
  },
  {
    category: 'New Arrivals',
    subtitle: 'Fresh seasonal looks just in',
    imageUrl: '/images/jacket_trench_modern_1795602450135.jpg',
    alt: 'New Arrivals ladies wear collection in Butwal',
  },
];

export function CategoryStrip({ products, onSelectCategory }: CategoryStripProps) {
  const getCount = (category: ProductCategory) =>
    category === 'New Arrivals'
      ? products.filter((p) => p.category === 'New Arrivals' || p.isNewArrival).length
      : products.filter((p) => p.category === category).length;

  return (
    <section className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14 border-b border-[#EADCE1]">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <p className="text-xs font-medium text-[#7A1C3A] tracking-wide mb-1.5">
            Curated Wardrobe
          </p>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619]">
            Shop by Category
          </h2>
        </div>
        <p className="text-sm text-[#645359] max-w-md">
          Thoughtfully curated dresses, festive ethnic ensembles, and everyday essentials tailored
          for women across Nepal.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {CATEGORY_CARDS.map((item) => {
          const count = getCount(item.category);
          return (
            <button
              key={item.category}
              type="button"
              onClick={() => onSelectCategory(item.category)}
              className="group text-left rounded-lg border border-[#EADCE1] bg-white overflow-hidden transition-transform duration-150 hover:-translate-y-0.5 hover:border-[#7A1C3A]/40 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#7A1C3A]"
            >
              <div className="aspect-[3/4] overflow-hidden bg-[#FDF5F7]">
                <ProductImage
                  src={item.imageUrl}
                  alt={item.alt}
                  className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-[1.03]"
                  label={item.category}
                />
              </div>
              <div className="p-3.5">
                <div className="flex items-center justify-between gap-1">
                  <h3 className="text-sm font-semibold text-[#1F1619] group-hover:text-[#7A1C3A] transition-colors truncate">
                    {item.category}
                  </h3>
                  <ArrowUpRight className="w-3.5 h-3.5 text-[#645359] group-hover:text-[#7A1C3A] shrink-0" />
                </div>
                <p className="text-xs text-[#645359] mt-0.5 tabular-nums">
                  {count} {count === 1 ? 'style' : 'styles'}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
